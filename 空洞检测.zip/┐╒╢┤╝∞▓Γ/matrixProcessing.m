% T = zeros(7, 7);
% for a = 1 : 7
%     [minValue, b] = min(A(:, a));
%     dif = L(a, b) / 2880 - minValue;
%     T(:, a) = A(:, a) + dif;
% end
% D = zeros(7, 7);
% for a = 1 : 7
%     for b = 1 : 7
%         D(a, b) = (T(a, b) - L(a, b) / 2880) / (1 / 240 - 1 / 2880);
%     end
% end

hold on
for a = 1 : 7
    plot([a, a], [1, 7], 'k-');
    plot([1, 7], [a, a], 'k-');
end

% filled_cells = [2, 2; 2, 3; 2, 5; 3, 2; 3, 3; 3, 4; 4, 4; 5, 3];
% 
% for i = 1:size(filled_cells, 1)
%     x = filled_cells(i, 1);
%     y = filled_cells(i, 2);
%     rectangle('Position', [x, y, 1, 1], 'FaceColor', 'yellow');
% end

for a = 1 : 7
    zero_indices = find(D1(a, :) == 0);
    dense_indices = find(D1(a, :) > 100);
    if size(zero_indices, 2) > 0
        for b = 1 : size(zero_indices, 2)
            plot([a, zero_indices(b)], [1, 7], 'k-');
        end
    end
    if size(dense_indices, 2) > 0
        for b = 1 : size(dense_indices, 2)
            plot([a, dense_indices(b)], [1, 7], 'r-');
        end
    end
end

% for a = 1 : 7
%     zero_indices = find(D2(a, :) == 0);
%     dense_indices = find(D2(a, :) > 100);
%     if size(zero_indices, 2) > 0
%         for b = 1 : size(zero_indices, 2)
%             plot([1, 7], [a, zero_indices(b)], 'k-');
%         end
%     end
%     if size(dense_indices, 2) > 0
%         for b = 1 : size(dense_indices, 2)
%             plot([1, 7], [a, dense_indices(b)], 'r-');
%         end
%     end
% end
