function jisuan4
    syms t1 t2;
    a = 0:pi/1000:pi;
    b = a;
    jisuan = inf;
    min_a = 0; % 保存最小值时的 a
    min_b = 0; % 保存最小值时的 b
    for i = a
        for j = b
            if abs(2*(1.5*cos(i)+1.47)*200/1.5/sin(i)+(1.5*cos(j)+2.11)*760/1.5/sin(j)-1000) < 0.5
                t1 = 200/1.5/sin(i)*2;
                t2 = 760/1.5/sin(j);
                x = t1 + t2;
                if x < jisuan
                    jisuan = x;
                    min_a = i; % 更新最小值时的 a
                    min_b = j; % 更新最小值时的 b
                end
            end
        end
    end
    jisuan = round(jisuan); % 或者使用 floor(jisuan)
    disp('最小时间值:');
    disp(jisuan); 
    disp('最小时间值时的 a 和 b:');
    disp(min_a);
    disp(min_b);
end